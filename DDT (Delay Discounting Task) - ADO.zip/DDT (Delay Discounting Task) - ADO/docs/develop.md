# For development

If you want to run the codes with your Python environment, the minimum
requirements are listed below. If you want to use your own Python environment to
run the task, 

* Python 3.7 or above
* ADOpy 0.4.1
* PyYAML 6.0
* PsychoPy 2021.2.3
* PyInstaller (optional, for building an executable)

## Getting started with poetry

One convenient tool to handle the project-wise Python environment is
[poetry][poetry] which sets up the environment based on dependencies in
`pyproject.toml`. If you want to try it, follow the instructions below.

1. Install Python 3.7 or above.
2. Install [poetry][poetry] on your local environment.
3. Open command prompt or PowerShell (Windows) or terminal (macOS, UNIX) and
   change the working directory to the downloaded location of the source codes.
4. Install the virtual environment with `poetry install`.
5. Activate the installed environment with `poetry shell`.
6. Run the task with `python main.py`.

[poetry]: https://python-poetry.org/

## Codes in `/src`

* `ado.py`: defined ADO-related classes
* `functions.py`: utility functions for DDT and ADO
* `drawer.py`: Drawer class that handles how to display stimuli on the screen
* `runner.py`: Runner class that actually runs the task timeline using the drawer

