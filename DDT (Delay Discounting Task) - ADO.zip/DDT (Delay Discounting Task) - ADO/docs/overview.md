# Overview

## Task: Delay discounting task (DDT)

<div align="center">
    <img width="80%" src="https://docs.adopy.org/en/stable/_images/delay-discounting-task.png" />
</div>

In the DDT, participants should choose preferred one out of given two options:
SS option (_Smaller, Sooner_) and LL option (_Larger, Later_). Each option has the
amount of reward and delay to get it. There are 4 design variables to handle
during the experiment as below.

* `r_ss` (amount of reward for the SS option)
* `r_ll` (amount of reward for the LL option)
* `t_ss` (delay to get the reward for the SS option)
* `t_ss` (delay to get the reward for the LL option)

During the task, ADO chooses the optimal set of design variables out of the pre-determined design space as below.

* `r_ss` is chosen from {$10, $20, ..., $790} (79 values).
* `r_ll` is fixed to $800.
* `t_ss` is fixed to "immediately".
* `t_ll` are chosen among the following 18 values:
  3 days, 5 days, 1 week, 2 weeks, 3 weeks,
  1 month, 6 weeks, 2 months, 10 weeks, 3 months,
  4 months, 5 months, 6 months, a year, 2 years,
  3 years, 5 years, and 10 years.

In brief, only two variables (`r_ss` and `t_ll`) can vary across trials.

## Model: Hyperbolic model ([Mazur, 1987][mazur1987])

Hyperbolic model poses that temporal discounting on the future reward appears in a hyperbolic function.
The model has two parameters: `logk` (log10 of the discounting rate) and `tau` (inverse temperature).

<div align="center">
    <img width="50%" src="./figures/eqn-hyperbolic.png" />
</div>

ADO estimates parameter distribution based on discretized parameter spaces defined as follows.
* `logk`: 51 points between -4 and 2 (`np.linspace(-4, 2, 51`)
* `tau`: 20 points from 0.1 to 2.0 (`np.linspace(0, 2, 21)[1:]`)

> Cf. You can find other candidate models for the DDT in [this link][ddt-model].

[mazur1987]: https://scholar.google.com/scholar?hl=en&q=An+adjusting+procedure+for+studying+delayed+reinforcement
[ddt-model]: https://docs.adopy.org/en/stable/api/tasks/dd.html#model

## Getting started

You can run the DDT with one of two options below:
(1) running the single executable file, or
(2) running `python main.py` with the Python environment.

### Before starting the task

| Step | Screenshot | Description |
|:---|:---:|:---|
| (1) Enter subject info | <img width="300px" src="./figures/prompt-1.png"/> | Enter subject information before running the program. Given subject information is stored in the data. |
| (2) Set the location to save data | <img width="300px" src="./figures/prompt-2.png"/> | Decide where to save the output data. The default filename is generated based on the user info from (1). |

* **Subject information to collect**
    * **Subject ID** (`ID`)
    * **Wave (`wave`)**: Baseline (`BL`), 6-month (`M6`), or 12-month (`M12`)
    * **Pre/Post** (`prepost`): Pre (`pre`) or Post (`post`)
    * **Main trials**: number of trials in the main block (default: 20 trials)
* **Default format for output filename**
    * `sub-{ID}_task-ddt_wave-{wave}_cond-{prepost}_beh.csv`
    * E.g., `sub-example1_task-ddt_wave-BL_cond-pre_beh.csv`, `sub-example2_task-ddt_wave-M6_cond-post_beh.csv`

#### Task flow within a trial

| Step | Screenshot | Duration (sec) | Description |
| :---: | :---: | :---: | :--- |
| **(1) Fixation** | <img width=300 src="./figures/task-1.png"/> | 1 | Shows a fixation cross for 1 second. |
| **(2) Stimuli** | <img width=300 src="./figures/task-2.png"/> | - | Displays two options and wait until responded. |
| **(3) Feedback** | <img width=300 src="./figures/task-3.png"/> | 1 | Highlights the chosen option for 1 second. |
| **(4) ITI** | <img width=300 src="./figures/task-4.png"/> | 0.5 | Shows an empty ITI screen for 0.5 second. |
