#!/usr/sh

poetry run pyinstaller \
  --name ddt \
  --add-data instructions.yml:. \
  --collect-all psychopy \
  --windowed \
  --onefile \
  main.py

