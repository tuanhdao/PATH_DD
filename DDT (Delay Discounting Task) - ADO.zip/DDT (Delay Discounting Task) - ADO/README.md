<div align="center">
    <img width="50%" src="./docs/figures/task-2.png" />
</div>

# ADO-powered delay discounting task

This repository is for Python codes of delay discounting task (DDT) using adaptive
design optimization (ADO; Cavagnaro et al., 2010; Myung et al., 2013).
This code largely depends on [ADOpy][adopy] for design selection (Yang et al., 2020).

The task can be built into the executable file with [PyInstaller][pyinstaller]
for both Windows and macOS, and only the prebuilt .exe file for Windows 10 is
released in the repository ([go to link][release]).

[adopy]: https://adopy.org

[pyinstaller]: http://www.pyinstaller.org/
[release]: https://github.com/CCS-Lab/ado-powered-ddt/releases

* **Documentation**
    * [Overview](https://github.com/CCS-Lab/ado-powered-ddt/blob/main/docs/overview.md)
    * [Development](https://github.com/CCS-Lab/ado-powered-ddt/blob/main/docs/develop.md)

## Repository structure

* `docs/`: documentation files
* `src/`: Python source codes for the delay discounting task
* `build.bat` (Windows), `build.sh` (macOS, UNIX): scripts to build the task
    into an single executable file
* `freetype.dll`: freetype font support for building an executable for Windows
* `instructions.yml`: instruction texts used in the DDT
* **`main.py`**: main code to run the DDT
* `pyproject.toml`: definitions of project dependencies (see more on
    [here][pyproject.toml])
* `poetry.lock`: specific version dependencies based on `pyproject.toml`,
    resolved with [`poetry`][poetry]

[pyproject.toml]: https://snarky.ca/what-the-heck-is-pyproject-toml/
[poetry]: https://python-poetry.org/

