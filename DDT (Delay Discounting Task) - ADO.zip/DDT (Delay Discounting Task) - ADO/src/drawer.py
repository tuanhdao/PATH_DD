# -*- coding: utf-8 -*-

from psychopy import visual

from .functions import convert_delay_to_str

__all__ = ['Drawer']


def calculate_box_vertices(x_center, y_center, width, height):
    return (
        (x_center - width / 2, y_center + height / 2),
        (x_center + width / 2, y_center + height / 2),
        (x_center + width / 2, y_center - height / 2),
        (x_center - width / 2, y_center - height / 2)
    )


class Drawer:
    """
    Drawer to display stimuli on the screen for the delay discounting task.
    """

    def __init__(self,
                 window: visual.Window,
                 *,
                 box_w: float = 0.35,
                 box_h: float = 0.25,
                 dist_from_center: float = 0.25,
                 text_font: str = 'Arial',
                 text_color: str = '#ffffff',
                 text_size: float = 0.05,
                 text_size_inst: float = 0.03,
                 text_margin: float = 0.04,
                 fixation_size: float = 0.1,
                 scale: float = 1,
                 ):
        self.window = window

        self.box_w = box_w * scale
        self.box_h = box_h * scale
        self.dist_from_center = dist_from_center * scale
        self.text_font = text_font
        self.text_color = text_color
        self.text_size = text_size * scale
        self.text_size_inst = text_size_inst * scale
        self.text_margin = text_margin * scale
        self.fixation_size = fixation_size * scale

        # Initialize stimuli as None and assign values into them
        self.box_left = None
        self.box_right = None
        self.text_reward_left = None
        self.text_reward_right = None
        self.text_delay_left = None
        self.text_delay_right = None
        self.text_inst = None
        self.fixation = None
        self.init_stim()

    def init_stim(self):
        self.box_left = visual.ShapeStim(
            self.window,
            lineWidth=8,
            lineColor='white',
            fillColor='black',
            vertices=calculate_box_vertices(-self.dist_from_center, 0,
                                            self.box_w, self.box_h),
        )
        self.box_right = visual.ShapeStim(
            self.window,
            lineWidth=8,
            lineColor='white',
            fillColor='black',
            vertices=calculate_box_vertices(self.dist_from_center, 0,
                                            self.box_w, self.box_h),
        )

        self.text_reward_left = visual.TextStim(
            self.window,
            text='',
            font=self.text_font,
            color=self.text_color,
            pos=(-self.dist_from_center, self.text_margin),
            height=self.text_size,
        )
        self.text_reward_right = visual.TextStim(
            self.window,
            text='',
            font=self.text_font,
            color=self.text_color,
            pos=(self.dist_from_center, self.text_margin),
            height=self.text_size,
        )

        self.text_delay_left = visual.TextStim(
            self.window,
            text='',
            font=self.text_font,
            color=self.text_color,
            pos=(-self.dist_from_center, -self.text_margin),
            height=self.text_size,
        )
        self.text_delay_right = visual.TextStim(
            self.window,
            text='',
            font=self.text_font,
            color=self.text_color,
            pos=(self.dist_from_center, -self.text_margin),
            height=self.text_size,
        )

        self.text_inst = visual.TextStim(
            self.window,
            text='',
            font=self.text_font,
            color=self.text_color,
            pos=(0, 0),
            wrapWidth=1,
            anchorVert='center',
            alignText='left',
            height=self.text_size,
        )

        self.fixation = visual.GratingStim(
            self.window,
            color='white',
            tex=None,
            mask='cross',
            size=self.fixation_size,
        )

    @staticmethod
    def _draw_option(box, text_reward, text_delay, reward, delay,
                     is_chosen=False):
        if is_chosen:
            box.lineWidth = 12
            box.fillColor = 'darkgreen'
        else:
            box.lineWidth = 8
            box.fillColor = None

        text_reward.text = f'${reward:.0f}'
        text_delay.text = convert_delay_to_str(delay)

        box.draw()
        text_reward.draw()
        text_delay.draw()

    def draw_option_left(self, reward, delay, is_chosen=False):
        self._draw_option(self.box_left, self.text_reward_left,
                          self.text_delay_left, reward, delay, is_chosen)

    def draw_option_right(self, reward, delay, is_chosen=False):
        self._draw_option(self.box_right, self.text_reward_right,
                          self.text_delay_right, reward, delay, is_chosen)

    def draw(self, r_ss, r_ll, t_ss, t_ll, is_left_ss=True, chosen=None,
             pos=None):
        if pos:
            xo, yo = float(pos[0]), float(pos[1])

            self.box_left.vertices = calculate_box_vertices(
                -self.dist_from_center + xo, yo, self.box_w, self.box_h)
            self.box_right.vertices = calculate_box_vertices(
                self.dist_from_center + xo, yo, self.box_w, self.box_h)

            self.text_reward_left.pos = (xo - self.dist_from_center,
                                         yo + self.text_margin)
            self.text_reward_right.pos = (xo + self.dist_from_center,
                                          yo + self.text_margin)
            self.text_delay_left.pos = (xo - self.dist_from_center,
                                        yo - self.text_margin)
            self.text_delay_right.pos = (xo + self.dist_from_center,
                                         yo - self.text_margin)

        if is_left_ss:
            r_left, r_right = r_ss, r_ll
            t_left, t_right = t_ss, t_ll
        else:
            r_left, r_right = r_ll, r_ss
            t_left, t_right = t_ll, t_ss

        self.draw_option_left(r_left, t_left, chosen == 'left')
        self.draw_option_right(r_right, t_right, chosen == 'right')

    def draw_fixation(self):
        self.fixation.draw()

    def draw_inst(self, text, pos=None, align_left=False, anchor_top=False):
        if pos:
            self.text_inst.pos = pos
        else:
            self.text_inst.pos = (0, 0)

        if align_left:
            self.text_inst.alignText = 'left'
        else:
            self.text_inst.alignText = 'center'

        if anchor_top:
            self.text_inst.anchorVert = 'top'
        else:
            self.text_inst.anchorVert = 'center'

        self.text_inst.text = text
        self.text_inst.draw()
