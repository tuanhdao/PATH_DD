# -*- coding: utf-8 -*-
import numpy as np
import pandas as pd
from adopy.base import Task, Model, Engine as BaseEngine
from adopy.functions import get_nearest_grid_index
from scipy.special import logsumexp, expit as inv_logit
from scipy.stats import bernoulli


class TaskDD(Task):
    """
    The Task class for the delay discounting task.

    Design variables
        - ``t_ss`` (:math:`t_{SS}`) - delay of a SS option
        - ``t_ll`` (:math:`t_{LL}`) - delay of a LL option
        - ``r_ss`` (:math:`R_{SS}`) - amount of reward of a SS option
        - ``r_ll`` (:math:`R_{LL}`) - amount of reward of a LL option

    Responses
        - ``choice`` - 0 (choosing a SS option) or 1 (choosing a LL option)
    """

    def __init__(self):
        super(TaskDD, self).__init__(
            name='Delay discounting task',
            designs=['r_ss', 'r_ll', 't_ss', 't_ll'],
            responses=['choice']  # Binary response
        )


class ModelHyp(Model):
    r"""
    The hyperbolic model for the delay discounting task (Mazur, 1987).
    .. math::
        \begin{align}
            D(t) &= \frac{1}{1 + kt} \\
            V_{LL} &= R_{LL} \cdot D(t_{LL}) \\
            V_{SS} &= R_{SS} \cdot D(t_{SS}) \\
            P(LL\, over \, SS) &= \frac{1}{1 + \exp [-\tau (V_{LL} - V_{SS})]}
        \end{align}

    Model parameters
        - ``logk`` (:math:`\log k`) - discounting parameter
        - ``tau`` (:math:`\tau`) - inverse temperature (:math:`\tau > 0`)

    References
    ----------
    Mazur, J. E. (1987). An adjusting procedure for studying delayed reinforcement.
    *Commons, ML.;Mazur, JE.; Nevin, JA*, 55–73.
    """

    def __init__(self):
        args = dict(
            name='Hyperbolic model for the DD task',
            task=TaskDD(),
            params=['logk', 'tau'])
        super().__init__(**args)

    def compute(self, choice, t_ss, t_ll, r_ss, r_ll, logk, tau):
        def discount(delay):
            return np.divide(1, 1 + np.power(10, logk) * delay)

        v_ss = r_ss * discount(t_ss)
        v_ll = r_ll * discount(t_ll)

        # Probability to choose an option with late and large rewards.
        p_obs = inv_logit(tau * (v_ll - v_ss))
        return bernoulli.logpmf(choice, p_obs)


class Engine(BaseEngine):
    def __init__(self,
                 *,
                 task,
                 model,
                 grid_design,
                 grid_param,
                 grid_response,
                 noise_ratio=1e-7,
                 lambda_et=None,
                 epsilon=0.001,
                 dtype=np.float32):
        super().__init__(task, model,
                         grid_design, grid_param, grid_response,
                         noise_ratio, dtype)

        self.trace = np.zeros(self.n_d)
        self.lambda_et = lambda_et
        self.epsilon = epsilon

    def reset(self):
        super().reset()
        self.trace = np.zeros(self.n_d)

    def get_design(self, kind='optimal'):
        if len(self.task.designs) == 0:
            return None

        if kind == 'optimal':
            w_design = np.exp(np.log(self.epsilon) * self.trace)
            idx_design = np.argmax(self.mutual_info * w_design)

        elif kind == 'random':
            idx_design = np.random.randint(self.n_d)

        else:
            raise ValueError(
                'The argument kind should be "optimal" or "random".')

        return self.grid_design.iloc[idx_design].to_dict()

    def update(self, design, response):
        if isinstance(design, list) != isinstance(response, list):
            raise ValueError(
                'The number of observations (pairs of design and response) '
                'should be matched in the design and response arguments.')

        if isinstance(design, list) and isinstance(response, list):
            if len(design) != len(response):
                raise ValueError(
                    'The length of designs and responses should be the same.')

            _designs = [
                pd.Series(d, index=self.task.designs, dtype=self.dtype)
                for d in design
            ]

            _responses = [
                pd.Series(r, index=self.task.responses, dtype=self.dtype)
                for r in response
            ]

        else:
            _designs = [
                pd.Series(design, index=self.task.designs, dtype=self.dtype)
            ]

            _responses = [
                pd.Series(response, index=self.task.responses,
                          dtype=self.dtype)
            ]

        for d, r in zip(_designs, _responses):
            i_d = get_nearest_grid_index(d.values, self.grid_design.values)
            i_y = get_nearest_grid_index(r.values, self.grid_response.values)
            self.log_post += self.log_lik[i_d, :, i_y]

            if self.lambda_et:
                self.trace *= self.lambda_et
                self.trace[i_d] += 1

        self.log_post -= logsumexp(self.log_post)

        self._marg_log_lik = None
        self._ent_marg = None
        self._ent_cond = None
        self._mutual_info = None

        self._update_mutual_info()
