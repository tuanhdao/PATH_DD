# -*- coding: utf-8 -*-
import numpy as np


def convert_delay_to_str(v):
    """
    Convert the delay value in a weekly unit into a human-readable string.
    """
    map_str = {
        0: 'Immediately',
        0.43: 'In 3 days',
        0.714: 'In 5 days',
        1: 'In a week',
        2: 'In 2 weeks',
        3: 'In 3 weeks',
        4.3: 'In a month',
        6.44: 'In 6 weeks',
        8.6: 'In 2 months',
        10.8: 'In 10 weeks',
        12.9: 'In 3 months',
        17.2: 'In 4 months',
        21.5: 'In 5 months',
        26: 'In 6 months',
        52: 'In a year',
        104: 'In 2 years',
        156: 'In 3 years',
        260: 'In 5 years',
        520: 'In 10 years'
    }

    keys = np.array(list(map_str.keys()))
    idx_closest = np.argmin(np.square(keys - v))
    key_closest = keys[idx_closest]

    return map_str[key_closest]


def generate_grid_design():
    """
    Generate grids for design variables of the delayed discounting task:
    `r_ss` (reward for the SS option), `r_ll` (reward for the LL option),
    `t_ss` (delay for the SS option), and `t_ll` (delay for the LL option).

    By definition of the SS and LL options, two condition should be met:
    `r_ss < r_ll`, and `t_ss < t_ll`.

    Grid values for delay should be represented in a weekly unit.
    """
    # Amounts of rewards
    r_ss = np.arange(10, 800, 10)
    r_ll = [800]  # r_ll is fixed to $800.

    # By definition of the SS and LL options, it uses cases where r_ss < r_ll.
    rewards = np.vstack([
        (rs, rl) for rs in r_ss for rl in r_ll if rs < rl
    ])

    # Delays (in a weekly unit)
    t_ss = [0]  # t_ss is fixed to 0 (immediately).
    t_ll = [
        0.43, 0.714, 1, 2, 3,
        4.3, 6.44, 8.6, 10.8, 12.9,
        17.2, 21.5, 26, 52, 104,
        156, 260, 520
    ]

    # By definition of the SS and LL options, it uses cases where t_ss < t_ll.
    delays = np.vstack([
        (ts, tl) for ts in t_ss for tl in t_ll if ts < tl
    ])

    return {
        ('r_ss', 'r_ll'): rewards,
        ('t_ss', 't_ll'): delays,
    }


def generate_grid_param():
    """
    Generate grids for model parameters of hyperbolic model:
    `k` (discounting rate), and `tau` (inverse temperature).
    """
    return {
        'logk': np.linspace(-4, 2, 51),
        'tau': np.linspace(0, 2, 21)[1:],
    }


def generate_grid_response():
    """
    Generate grids for the response variable of the delay discounting task:
    `choice` (0 for the SS option, and 1 for the LL option).
    """
    return {
        'choice': [0, 1]
    }
